

// PROGRAM 3 LAMPU LALU LINTAS ARDUINO UNO

// Menentukan pin setiap lampu LED
int ledKuning = 11;
int ledMerah = 10;
int ledHijau = 9;

void setup() {
  // Memulai komunikasi Serial Monitor
  Serial.begin(9600);

  // Mengatur pin LED sebagai OUTPUT
  pinMode(ledKuning, OUTPUT);
  pinMode(ledMerah, OUTPUT);
  pinMode(ledHijau, OUTPUT);
}

void loop() {

  // =================================
  // 1. KONDISI LAMPU HIJAU MENYALA
  // =================================

  digitalWrite(ledHijau, HIGH);  // Lampu hijau menyala
  digitalWrite(ledKuning, LOW);  // Lampu kuning mati
  digitalWrite(ledMerah, LOW);   // Lampu merah mati

  Serial.println("Lampu Hijau Menyala");
  Serial.println("Lampu Kuning Mati");
  Serial.println("Lampu Merah Mati");
  Serial.println("----------------------");

  delay(3000); // Menunggu selama 3 detik


  // =================================
  // 2. KONDISI LAMPU KUNING MENYALA
  // =================================

  digitalWrite(ledHijau, LOW);   // Lampu hijau mati
  digitalWrite(ledKuning, HIGH); // Lampu kuning menyala
  digitalWrite(ledMerah, LOW);   // Lampu merah mati

  Serial.println("Lampu Hijau Mati");
  Serial.println("Lampu Kuning Menyala");
  Serial.println("Lampu Merah Mati");
  Serial.println("----------------------");

  delay(2000); // Menunggu selama 2 detik


  // =================================
  // 3. KONDISI LAMPU MERAH MENYALA
  // =================================

  digitalWrite(ledHijau, LOW);   // Lampu hijau mati
  digitalWrite(ledKuning, LOW);  // Lampu kuning mati
  digitalWrite(ledMerah, HIGH);  // Lampu merah menyala

  Serial.println("Lampu Hijau Mati");
  Serial.println("Lampu Kuning Mati");
  Serial.println("Lampu Merah Menyala");
  Serial.println("----------------------");

  delay(3000); // Menunggu selama 3 detik

}

